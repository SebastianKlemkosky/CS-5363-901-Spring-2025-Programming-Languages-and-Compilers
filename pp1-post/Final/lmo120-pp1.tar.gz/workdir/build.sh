#!/bin/bash
# build.sh: build script for Python project

echo "This project was developed using Python 3.11.9."
echo "This project uses only standard Python libraries."
