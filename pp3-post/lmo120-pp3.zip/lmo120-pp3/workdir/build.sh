#!/bin/bash
# build.sh: build script for Python project

echo "This project was developed using Python 3.13.3"
echo "This project uses only standard Python libraries."
